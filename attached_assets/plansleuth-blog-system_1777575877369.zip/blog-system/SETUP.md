# PlanSleuth Blog System — Drop-in Package

This package contains a complete dynamic blog system, admin portal, and waitlist signup feature. It was built on a **pnpm monorepo** with this structure:

```
lib/db/                      Drizzle ORM database package (@workspace/db)
artifacts/api-server/        Express API server (@workspace/api-server)
artifacts/<your-app>/        Vite + React + Wouter frontend
```

If your target project uses the same monorepo layout (which it should — that's why we packaged it this way), file paths line up cleanly. If your frontend artifact is named something other than `plansleuth`, just substitute that name everywhere you see `<your-app>` below.

---

## What's included

```
db/schema/                          → goes into lib/db/src/schema/
  blog-posts.ts
  admin-users.ts
  admin-sessions.ts
  waitlist-signups.ts

api-server/lib/                     → goes into artifacts/api-server/src/lib/
  auth.ts        (admin sessions, sha256-hashed tokens, requireAdmin middleware, bootstrapAdmin)
  blog.ts        (slugify, scheduled-post promoter background job)

api-server/routes/                  → goes into artifacts/api-server/src/routes/
  admin-auth.ts  (POST /api/admin/auth/login, /logout, GET /me)
  admin-blog.ts  (CRUD for posts under /api/admin/blog/*)
  blog.ts        (public GET /api/blog/posts, /api/blog/posts/:slug)
  seo.ts         (sitemap.xml, robots.txt)
  waitlist.ts    (POST /api/waitlist + admin list/csv/delete)

frontend/components/                → goes into artifacts/<your-app>/src/components/
  admin-shell.tsx   (admin nav shell, AdminGuard, NewPostButton)
  markdown.tsx      (markdown renderer using react-markdown + remark-gfm)

frontend/hooks/                     → goes into artifacts/<your-app>/src/hooks/
  use-admin.ts      (TanStack Query hooks for admin auth)
  use-meta.ts       (client-side <head> meta + JSON-LD injector)

frontend/lib/                       → goes into artifacts/<your-app>/src/lib/
  blog-api.ts       (typed fetch client for everything: blog, adminBlog, waitlist, adminWaitlist, adminAuth)

frontend/pages/blog/                → goes into artifacts/<your-app>/src/pages/blog/
  index.tsx         (public blog listing /blog)
  post.tsx          (public post detail /blog/:slug)

frontend/pages/blogadmin/           → goes into artifacts/<your-app>/src/pages/blogadmin/
  login.tsx         (/blogadmin/login)
  dashboard.tsx     (/blogadmin)
  editor.tsx        (/blogadmin/new and /blogadmin/edit/:id — markdown editor + SEO + scheduling + autosave)
  waitlist.tsx      (/blogadmin/waitlist — table + CSV export + delete)
```

---

## Setup steps for the receiving agent

### 1. Provision a Postgres database

Use Replit's built-in Postgres (or any PG instance). The `DATABASE_URL` env var must be set. The `lib/db` package reads it at startup.

### 2. Set required secrets

| Secret | Required? | What for |
|---|---|---|
| `DATABASE_URL` | yes | Postgres connection string (auto-set by Replit when you provision a DB) |
| `ADMIN_EMAIL` | yes | Bootstrap admin login email |
| `ADMIN_PASSWORD` | yes | Bootstrap admin login password |
| `PUBLIC_SITE_ORIGIN` | production only | The canonical https origin used in `sitemap.xml` URLs and SEO canonical tags. Example: `https://plansleuth.com`. In dev, the server falls back to the request host. |

The API server's `bootstrapAdmin()` function runs on startup; it will create the admin row if it doesn't exist, and **upsert** the password hash on every restart, so changing `ADMIN_PASSWORD` and restarting is how you rotate the admin password.

### 3. Install npm packages

**In `lib/db/package.json` `dependencies`:** (add any that aren't already there)
- `drizzle-orm` (catalog version of the workspace, or `^0.40.0`)
- `drizzle-zod` `^0.8.3`  ← important, this version requires `zod/v4` imports
- `pg` `^8.20.0`
- `zod` (catalog or `^4`)

**In `lib/db/package.json` `devDependencies`:**
- `@types/pg` `^8.18.0`
- `drizzle-kit` `^0.31.9`

**In `artifacts/api-server/package.json` `dependencies`:** (add if missing)
- `cookie-parser` `^1.4.7`
- `cors` `^2`
- `express` `^5`
- `pino` `^9`
- `pino-http` `^10`

**In `artifacts/api-server/package.json` `devDependencies`:**
- `@types/cookie-parser` `^1.4.10`
- `@types/cors` `^2.8.19`
- `@types/express` `^5.0.6`

**In `artifacts/<your-app>/package.json` `dependencies`:**
- `react-markdown` `^10.1.0`
- `remark-gfm` `^4.0.1`

**In `artifacts/<your-app>/package.json` `devDependencies`:** (these are required by the components — many will already be present in a shadcn/ui-flavored project)
- `@tanstack/react-query` (catalog)
- `wouter` `^3.3.5`
- `lucide-react` (catalog)
- `react-hook-form` `^7.55.0` (used by ui/form components)
- `@radix-ui/react-alert-dialog` `^1.1.7` (waitlist delete confirm)
- `@radix-ui/react-accordion` `^1.2.4` (editor SEO accordion)
- `@radix-ui/react-tabs` `^1.1.4` (editor preview tab)
- `@radix-ui/react-select` `^2.1.7` (editor status select)
- `@radix-ui/react-popover` `^1.1.7` (date pickers)
- `@radix-ui/react-label` `^2.1.3`
- `@radix-ui/react-dialog` `^1.1.7`
- `@radix-ui/react-slot` `^1.2.0`
- `date-fns` `^3.6.0`
- `react-day-picker` `^9.11.1`
- `class-variance-authority` (catalog)
- `tailwind-merge` (catalog)
- `clsx` (catalog)
- `tailwindcss` (catalog) + `@tailwindcss/typography` `^0.5.15` (the post page uses `prose` classes)
- `zod` (catalog)

Then run `pnpm install` from the workspace root.

### 4. Drop in the files

Copy each folder into the corresponding location described above. Don't overwrite existing barrel/index files — instead, **add lines** to them as described in step 5.

### 5. Wire up the existing barrel/index files

**`lib/db/src/schema/index.ts`** — add these exports (keep any existing ones):
```ts
export * from "./blog-posts";
export * from "./admin-users";
export * from "./admin-sessions";
export * from "./waitlist-signups";
```

**`artifacts/api-server/src/routes/index.ts`** — wire the routers in this exact order (the order matters; see "Gotchas" below):
```ts
import { Router, type IRouter } from "express";
import healthRouter from "./health";
import blogRouter from "./blog";
import seoRouter from "./seo";
import adminAuthRouter from "./admin-auth";
import waitlistRouter from "./waitlist";
import adminBlogRouter from "./admin-blog";

const router: IRouter = Router();
router.use(healthRouter);     // optional, your existing health route
router.use(blogRouter);
router.use(seoRouter);
router.use(adminAuthRouter);
router.use(waitlistRouter);
router.use(adminBlogRouter);  // MUST be last — see gotcha #1

export default router;
```

**`artifacts/api-server/src/app.ts`** — make sure these lines are present (in addition to your existing `cors`, `express.json`, etc.):
```ts
import cookieParser from "cookie-parser";
import { bootstrapAdmin } from "./lib/auth";
import { startScheduler } from "./lib/blog";

app.use(cookieParser());
app.use(express.json({ limit: "2mb" }));   // posts can be larger than the default 100kb
app.use("/api", router);

bootstrapAdmin().catch(console.error);     // creates / updates the admin user from env
startScheduler();                          // promotes scheduled posts every 30s
```

**`artifacts/<your-app>/src/App.tsx`** — register the routes (keep your existing routes; just add these):
```tsx
import BlogIndex from "@/pages/blog";
import BlogPostPage from "@/pages/blog/post";
import BlogAdminLogin from "@/pages/blogadmin/login";
import BlogAdminDashboard from "@/pages/blogadmin/dashboard";
import BlogAdminEditor from "@/pages/blogadmin/editor";
import BlogAdminWaitlist from "@/pages/blogadmin/waitlist";

// inside <Switch>
<Route path="/blog" component={BlogIndex} />
<Route path="/blog/:slug" component={BlogPostPage} />
<Route path="/blogadmin" component={BlogAdminDashboard} />
<Route path="/blogadmin/login" component={BlogAdminLogin} />
<Route path="/blogadmin/new" component={BlogAdminEditor} />
<Route path="/blogadmin/edit/:id" component={BlogAdminEditor} />
<Route path="/blogadmin/waitlist" component={BlogAdminWaitlist} />
```

You also need a `QueryClientProvider` at the root if you don't have one yet:
```tsx
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
const queryClient = new QueryClient();
// wrap your app: <QueryClientProvider client={queryClient}>...</QueryClientProvider>
```

### 6. Wire the waitlist form into the existing landing page

In whatever component renders the existing email signup form on the landing page:

```tsx
import { useState } from "react";
import { waitlist } from "@/lib/blog-api";

const [email, setEmail] = useState("");
const [submitted, setSubmitted] = useState(false);
const [submitting, setSubmitting] = useState(false);
const [error, setError] = useState<string | null>(null);

const handleSubmit = async (e: React.FormEvent) => {
  e.preventDefault();
  if (!email || submitting) return;
  setSubmitting(true);
  setError(null);
  try {
    await waitlist.signup(email, "home");  // 2nd arg is a "source" label, useful if you have multiple forms
    setSubmitted(true);
    setEmail("");
  } catch (err: any) {
    setError(err?.message || "Something went wrong. Please try again.");
  } finally {
    setSubmitting(false);
  }
};
```

The endpoint is idempotent — submitting the same email twice returns 201 both times and never creates a duplicate row.

### 7. Push the database schema

From the workspace root:
```bash
pnpm --filter @workspace/db run push
```

This creates the four tables (`blog_posts`, `admin_users`, `admin_sessions`, `waitlist_signups`) in your Postgres database.

### 8. Restart and use

Restart the API server workflow. Then:
- **Sign in** at `/blogadmin/login` with `ADMIN_EMAIL` and `ADMIN_PASSWORD`.
- **Create a blog post** from `/blogadmin/new`. You can save as Draft, Publish immediately, or Schedule for a future date. The editor has a markdown textarea + live preview tab and autosaves every 1.5s after the first save.
- **View signups** at `/blogadmin/waitlist`. Click "Export CSV" to download.

---

## Gotchas

### 1. Router mount order — `waitlistRouter` must come BEFORE `adminBlogRouter`
The admin-blog router uses `router.use("/admin/blog", requireAdmin)` which is path-scoped, so the order shouldn't strictly matter for auth correctness — but keeping the unauth'd public routes (`waitlist`, `blog`, `seo`) before `adminBlog` is a defensive habit. If you ever revert the path-scoping, the order becomes load-bearing.

### 2. `drizzle-zod@0.8` requires `zod/v4` imports
The schema files import from `zod/v4`, not `zod`. Don't "fix" this — it's required for `drizzle-zod@0.8` compatibility.

### 3. `express.json({ limit: "2mb" })`
The default 100kb limit is too small for blog post bodies. The middleware bump to 2mb is in `app.ts`.

### 4. SEO meta tags are client-side only
`use-meta.ts` injects `<title>`, `<meta name="description">`, OpenGraph tags, and JSON-LD into `<head>` from the SPA. Most modern crawlers (including Google) execute JS, but if you need crawler-perfect SSR SEO, you'd need to add prerendering or move to a SSR framework. The sitemap (`/api/blog/sitemap.xml`) is server-rendered.

### 5. Featured images are URL-only
The editor takes an image URL (paste a public URL). There's no upload UI. Easiest option: drop images into your project's `public/` folder and reference them by path, or paste a URL from your image host of choice.

### 6. Sessions
Session cookies are httpOnly, sameSite=lax, secure in production. Cookie name: `blogadmin_session`. Tokens are random bytes; only the **sha256 hash** is stored in the DB. Sessions last 30 days.

### 7. CSV export is formula-injection-safe
Any cell starting with `=`, `+`, `-`, `@`, tab, or CR is prefixed with `'` before export to prevent malicious values from executing as Excel/Sheets formulas.

---

## API surface (for reference)

### Public
- `GET /api/blog/posts?page=1&pageSize=10&search=&category=` — list published posts
- `GET /api/blog/posts/:slug` — single post detail
- `GET /api/blog/sitemap.xml`
- `GET /api/blog/robots.txt`
- `POST /api/waitlist` — body `{ email, source? }`, returns `{ ok: true }` (201). Idempotent.

### Admin (cookie-protected)
- `POST /api/admin/auth/login` — body `{ email, password }`, sets `blogadmin_session` cookie
- `POST /api/admin/auth/logout`
- `GET /api/admin/auth/me`
- `GET /api/admin/blog/posts?page=&pageSize=&status=&search=&author=&category=`
- `POST /api/admin/blog/posts` — create
- `PATCH /api/admin/blog/posts/:id` — update
- `DELETE /api/admin/blog/posts/:id`
- `GET /api/admin/blog/slug-check?slug=foo&excludeId=...`
- `GET /api/admin/waitlist` — list signups
- `GET /api/admin/waitlist.csv` — download CSV
- `DELETE /api/admin/waitlist/:id`

---

## What's NOT included (and how to handle it)

- **shadcn/ui components** (`@/components/ui/button`, `card`, `input`, `dialog`, `accordion`, `tabs`, `select`, `popover`, `label`, `dropdown-menu`, `alert-dialog`, `calendar`, `badge`). The frontend files import from `@/components/ui/*`. If your existing landing page is shadcn-based, you almost certainly already have these. If not, run the shadcn CLI to add them, e.g.:
  ```bash
  npx shadcn@latest add button card input dialog accordion tabs select popover label dropdown-menu alert-dialog calendar badge
  ```
- **The `@/` path alias.** This is configured in `vite.config.ts` and `tsconfig.json` to point at `./src`. Should already be set in any Vite + React project that uses shadcn/ui.
- **`SiteNav` / `SiteFooter`.** The blog pages import these from `@/components/site-nav` and `@/components/site-footer` to keep the public site visually consistent. You probably already have your own — just make sure those import paths resolve, or edit the blog pages to use your existing nav/footer components.
- **Your existing landing page styling.** Untouched. Just wire the waitlist form via `waitlist.signup()` (step 6).

That's it. If anything blows up after wiring, the most likely culprits are (in order): missing env secret, missing npm package, wrong router mount order, or the `@/` alias not pointing where the imports expect.
